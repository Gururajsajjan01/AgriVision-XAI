# Model artifacts

No model is trained or included. Add artifacts only alongside provenance and measured evaluation records. Large model files are excluded from Git.
