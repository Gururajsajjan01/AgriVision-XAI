No data is bundled and no model scores are claimed. Keep acquired data under raw/ (gitignored), derived data under processed/ (gitignored), and record exact source/license/citation, release/version, counts, preprocessing, and split in research/dataset_documentation.md before training.

## Soil crop recommendation
The accepted CSV columns are N, P, K, temperature, humidity, ph, rainfall, plus a target named label, crop, crop_name, or target (case-insensitive). This repository does not impose an unverified crop dataset. Check geographic relevance, units, provenance, and usage terms. Save a selected CSV to raw/crop_recommendation.csv and run `python scripts/train_crop_model.py ../data/raw/crop_recommendation.csv` from backend/.

## Plant disease images
PlantVillage is available through [Mendeley Data](https://data.mendeley.com/datasets/tywbtsjrjv/1), and was introduced in Hughes and Salathé ([paper](https://arxiv.org/abs/1511.08060)). Often-cited counts (54,306 images/38 categories) describe a published release, not files in this workspace. Check the current dataset terms/license and document the exact release obtained. The images are largely controlled-condition and do not establish field performance. Arrange `raw/plant_disease/CLASS_NAME/image.jpg`; run `python scripts/train_disease_model.py ../data/raw/plant_disease`. TensorFlow is optional through `requirements-vision.txt` and needs a supported Python/platform combination.

## Crop product image classification
Choose a dataset whose license permits the intended use and document actual classes and counts. Arrange `raw/crop_images/CLASS_NAME/*`; run `python scripts/train_crop_classifier.py ../data/raw/crop_images`. The inference API uses only classes in the trained class manifest.

Never commit raw datasets, farmer uploads, model artifacts, or API keys. Model metrics and counts stay absent until an actual evaluation run.
