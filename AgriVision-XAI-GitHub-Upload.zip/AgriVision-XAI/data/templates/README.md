No sample crop or disease values are prefilled. Add only values you can verify from the referenced source.
