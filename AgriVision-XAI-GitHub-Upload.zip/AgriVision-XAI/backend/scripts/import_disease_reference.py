import argparse
import csv
from pathlib import Path
from sqlalchemy import select
from app.models.database import DiseaseInformation, SessionLocal, Source

required = {"label", "source_name", "source_url", "citation", "license"}
parser = argparse.ArgumentParser(description="Import verified disease information. Every entry must cite a source.")
parser.add_argument("csv_file")
args = parser.parse_args()
db = SessionLocal()
count = 0
try:
    with Path(args.csv_file).open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if required - set(reader.fieldnames or []):
            raise ValueError(f"CSV missing required columns: {sorted(required - set(reader.fieldnames or []))}")
        for row in reader:
            if not all(row.get(key, "").strip() for key in required):
                raise ValueError(f"Disease row {reader.line_num} lacks source provenance")
            source = db.scalar(select(Source).where(Source.url == row["source_url"].strip()))
            if not source:
                source = Source(name=row["source_name"].strip(), url=row["source_url"].strip(), citation=row["citation"].strip(), license=row["license"].strip())
                db.add(source); db.flush()
            record = db.scalar(select(DiseaseInformation).where(DiseaseInformation.label.ilike(row["label"].strip())))
            values = {key: row.get(key, "").strip() for key in ("common_name", "crop", "summary", "management", "prevention")}
            if record:
                for key, value in values.items(): setattr(record, key, value)
                record.source_id = source.id
            else:
                db.add(DiseaseInformation(label=row["label"].strip(), source_id=source.id, **values))
            count += 1
    db.commit()
    print(f"Imported or updated {count} source-backed disease records")
finally:
    db.close()
