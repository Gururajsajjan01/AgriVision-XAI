import argparse
import json
from app.ml.disease_detection.train import train_image_model
parser = argparse.ArgumentParser(description="Train disease classifier from class-folder leaf images.")
parser.add_argument("dataset_dir")
parser.add_argument("--model-dir", default="../models")
parser.add_argument("--architecture", choices=["MobileNetV2", "EfficientNetB0", "ResNet50"], default="MobileNetV2")
parser.add_argument("--epochs", type=int, default=8)
args = parser.parse_args()
print(json.dumps(train_image_model(args.dataset_dir, args.model_dir, "disease_detection", args.architecture, args.epochs), indent=2))
