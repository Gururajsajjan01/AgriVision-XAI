import argparse
import json
from app.ml.crop_classification.train import train_crop_classifier
parser = argparse.ArgumentParser(description="Train crop image classifier from per-class folders.")
parser.add_argument("dataset_dir")
parser.add_argument("--model-dir", default="../models")
parser.add_argument("--architecture", choices=["MobileNetV2", "EfficientNetB0", "ResNet50"], default="MobileNetV2")
parser.add_argument("--epochs", type=int, default=8)
args = parser.parse_args()
print(json.dumps(train_crop_classifier(args.dataset_dir, args.model_dir, args.architecture, args.epochs), indent=2))
