import argparse
from app.data.loaders.crop_catalog import import_catalog
from app.models.database import SessionLocal

parser = argparse.ArgumentParser(description="Import verified crop facts from a provenance-required CSV.")
parser.add_argument("csv_file")
args = parser.parse_args()
db = SessionLocal()
try:
    print(f"Imported or updated {import_catalog(db, args.csv_file)} source-backed crop records")
finally:
    db.close()
