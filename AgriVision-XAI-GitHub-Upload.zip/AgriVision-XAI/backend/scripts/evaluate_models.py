"""Display only persisted results from actual evaluation runs."""
import json
from pathlib import Path
files = sorted(Path("../models").glob("*.metrics.json"))
if not files:
    print("Not evaluated yet.")
for file in files:
    print(f"\n{file.name}")
    print(json.dumps(json.loads(file.read_text(encoding="utf-8")), indent=2))
