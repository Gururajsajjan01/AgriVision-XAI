import argparse
import json
from app.ml.crop_recommendation.train import train_model
parser = argparse.ArgumentParser(description="Train and evaluate a Random Forest from a documented crop dataset CSV.")
parser.add_argument("dataset", help="CSV with N,P,K,temperature,humidity,ph,rainfall and crop/label target")
parser.add_argument("--model-dir", default="../models")
parser.add_argument("--seed", type=int, default=42)
args = parser.parse_args()
print(json.dumps(train_model(args.dataset, args.model_dir, args.seed), indent=2))
