from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect
revision = "0002_nutrition_micros"
down_revision = "0001_initial"
branch_labels = None
depends_on = None
def upgrade():
    existing = {column["name"] for column in inspect(op.get_bind()).get_columns("nutrition")}
    for name in ("magnesium_mg", "zinc_mg", "vitamin_b6_mg", "vitamin_e_mg"):
        if name not in existing:
            op.add_column("nutrition", sa.Column(name, sa.Float(), nullable=True))
def downgrade():
    existing = {column["name"] for column in inspect(op.get_bind()).get_columns("nutrition")}
    for name in ("vitamin_e_mg", "vitamin_b6_mg", "zinc_mg", "magnesium_mg"):
        if name in existing:
            op.drop_column("nutrition", name)
