import pandas as pd
import pytest
from app.ml.crop_recommendation.train import train_model

def test_train_writes_measured_manifest(tmp_path):
    rows=[]
    for label, offset in [('crop-a',0),('crop-b',30)]:
        for i in range(10): rows.append({'N':10+i+offset,'P':20+i,'K':30+i,'temperature':20+i,'humidity':40+i,'ph':5.5+i/10,'rainfall':60+i*2,'label':label})
    data=tmp_path/'crop.csv'; pd.DataFrame(rows).to_csv(data,index=False)
    out=tmp_path/'models'
    metrics=train_model(data,out)
    assert metrics['dataset_samples']==20
    assert metrics['test_samples']>0
    assert (out/'crop_recommendation.metrics.json').exists()
    assert (out/'crop_recommendation.joblib').exists()
