from pathlib import Path
import pandas as pd
import pytest
from app.ml.crop_recommendation.preprocess import load_crop_csv
def test_crop_csv_schema_and_values(tmp_path:Path):
    path=tmp_path/"data.csv"
    pd.DataFrame({"N":[10,20],"P":[2,3],"K":[4,5],"temperature":[21,23],"humidity":[50,51],"ph":[6,7],"rainfall":[80,90],"label":["crop-a","crop-b"]}).to_csv(path,index=False)
    assert len(load_crop_csv(path))==2
def test_crop_csv_rejects_missing_features(tmp_path:Path):
    path=tmp_path/"bad.csv"; pd.DataFrame({"label":["a","b"]}).to_csv(path,index=False)
    with pytest.raises(ValueError): load_crop_csv(path)
