import asyncio
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models.database import Base, CropInformation, NutritionEntry, Source
from app.services.crop_service import get_crop, list_crops
from app.services.nutrition_service import lookup_food

def make_session():
    engine=create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()

def test_crop_lookup_and_search():
    db=make_session(); db.add(CropInformation(name="Example crop",category="Grains")); db.commit()
    assert get_crop(db,"example crop").name=="Example crop"
    assert len(list_crops(db,search="example",category="Grains"))==1
    db.close()

def test_local_nutrition_lookup_has_source():
    db=make_session(); db.add(NutritionEntry(food_name="Sample food",calories_kcal=10,source_name="Test source",source_url="https://example.test")); db.commit()
    result=asyncio.run(lookup_food(db,"Sample food"))
    assert result["nutrients"]["calories_kcal"]==10
    assert result["source"]=="Test source"
    db.close()
