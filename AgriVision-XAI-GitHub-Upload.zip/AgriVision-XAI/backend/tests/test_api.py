import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.main import app
from app.models.database import Base, get_db
engine = create_engine("sqlite://", connect_args={"check_same_thread":False}, poolclass=StaticPool)
TestingSession=sessionmaker(bind=engine,autoflush=False,autocommit=False)
Base.metadata.create_all(engine)
def override_db():
    db=TestingSession()
    try: yield db
    finally: db.close()
app.dependency_overrides[get_db]=override_db
client=TestClient(app)
def test_health():
    response=client.get("/api/health")
    assert response.status_code==200 and response.json()["database"]=="ok"
def test_soil_rejects_out_of_range_values():
    r=client.post("/api/crop/recommend",json={"nitrogen":-1,"phosphorus":1,"potassium":1,"temperature":20,"humidity":50,"ph":6,"rainfall":20})
    assert r.status_code==422
def test_valid_soil_reports_unavailable_model_until_trained():
    r=client.post("/api/crop/recommend",json={"nitrogen":12,"phosphorus":8,"potassium":10,"temperature":22,"humidity":55,"ph":6.2,"rainfall":70})
    assert r.status_code==503
def test_crop_catalog_empty_and_lookup_not_found():
    assert client.get("/api/crops").json()==[]
    assert client.get("/api/crops/Rice").status_code==404
def test_feedback_saved():
    r=client.post("/api/feedback",json={"module":"crop_recommendation","useful":True,"comment":"clear"})
    assert r.status_code==201 and r.json()["received"]
def test_model_status_reports_not_evaluated():
    r=client.get("/api/models/status")
    assert r.status_code==200
def test_disease_upload_rejects_unsupported_mime():
    r=client.post("/api/disease/predict",files={"file":("leaf.gif",b"GIF89a","image/gif")})
    assert r.status_code==415
def test_knowledge_catalogs_are_empty_without_verified_imports():
    assert client.get("/api/diseases").json()==[]
    assert client.get("/api/sources").json()==[]
