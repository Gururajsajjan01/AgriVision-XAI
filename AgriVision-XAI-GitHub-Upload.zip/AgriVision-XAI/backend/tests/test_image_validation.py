from io import BytesIO
from PIL import Image
import pytest
from app.ml.disease_detection.preprocess import validate_image_bytes
def test_valid_image():
    b=BytesIO(); Image.new("RGB",(8,8),"green").save(b,format="PNG")
    assert validate_image_bytes(b.getvalue(),100000)
def test_rejects_invalid_image():
    with pytest.raises(ValueError): validate_image_bytes(b"not image",100000)
def test_rejects_oversized_image():
    with pytest.raises(ValueError): validate_image_bytes(b"12345",4)
