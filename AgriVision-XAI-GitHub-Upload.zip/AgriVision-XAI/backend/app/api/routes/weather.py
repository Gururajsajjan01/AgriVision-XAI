from fastapi import APIRouter
from app.models.schemas import WeatherInput
from app.services.weather_service import get_weather

router = APIRouter(tags=["weather"])

@router.get("/weather")
async def weather(latitude: float, longitude: float):
    body = WeatherInput(latitude=latitude, longitude=longitude)
    return await get_weather(body.latitude, body.longitude)
