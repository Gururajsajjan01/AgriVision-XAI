import secrets

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models.database import CropInformation, DiseaseInformation, Feedback, Source, get_db
from app.models.schemas import AdminCropInput, AdminSourceInput
from app.services.model_status_service import get_model_status


def require_admin(x_admin_key: str | None = Header(default=None, alias="X-Admin-Key")):
    configured_key = get_settings().admin_api_key
    if not configured_key:
        raise HTTPException(status_code=503, detail="Admin access is disabled. Set ADMIN_API_KEY in backend/.env and restart the API.")
    if not x_admin_key or not secrets.compare_digest(x_admin_key, configured_key):
        raise HTTPException(status_code=401, detail="Admin key is missing or incorrect.")


router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_admin)])


def _crop_record(db: Session, crop: CropInformation):
    source = db.get(Source, crop.source_id) if crop.source_id else None
    return {
        "id": crop.id,
        "name": crop.name,
        "category": crop.category,
        "scientific_name": crop.scientific_name,
        "suitable_soil": crop.suitable_soil,
        "ph_min": crop.ph_min,
        "ph_max": crop.ph_max,
        "temperature_min_c": crop.temperature_min_c,
        "temperature_max_c": crop.temperature_max_c,
        "rainfall_min_mm": crop.rainfall_min_mm,
        "rainfall_max_mm": crop.rainfall_max_mm,
        "water_requirements": crop.water_requirements,
        "growing_season": crop.growing_season,
        "growth_duration_days": crop.growth_duration_days,
        "nutrient_requirements": crop.nutrient_requirements,
        "common_diseases": crop.common_diseases,
        "cultivation": crop.cultivation,
        "uses": crop.uses,
        "source_id": crop.source_id,
        "source_name": source.name if source else None,
    }


@router.get("/overview")
def admin_overview(db: Session = Depends(get_db)):
    count = lambda model: db.scalar(select(func.count()).select_from(model)) or 0
    return {
        "crop_count": count(CropInformation),
        "source_count": count(Source),
        "disease_count": count(DiseaseInformation),
        "feedback_count": count(Feedback),
        "models": get_model_status(db),
    }


@router.get("/sources")
def admin_sources(db: Session = Depends(get_db)):
    rows = db.scalars(select(Source).order_by(Source.name)).all()
    return [{"id": row.id, "name": row.name, "url": row.url, "citation": row.citation, "license": row.license} for row in rows]


@router.post("/sources", status_code=201)
def create_source(body: AdminSourceInput, db: Session = Depends(get_db)):
    url = str(body.url)
    if db.scalar(select(Source).where(Source.url == url)):
        raise HTTPException(status_code=409, detail="A source with this URL already exists.")
    source = Source(name=body.name.strip(), url=url, citation=body.citation.strip(), license=body.license.strip())
    db.add(source)
    db.commit()
    db.refresh(source)
    return {"id": source.id, "name": source.name, "url": source.url, "citation": source.citation, "license": source.license}


@router.delete("/sources/{source_id}")
def delete_source(source_id: int, db: Session = Depends(get_db)):
    source = db.get(Source, source_id)
    if not source:
        raise HTTPException(status_code=404, detail="Source not found.")
    used_by_crop = db.scalar(select(CropInformation.id).where(CropInformation.source_id == source_id).limit(1))
    used_by_disease = db.scalar(select(DiseaseInformation.label).where(DiseaseInformation.source_id == source_id).limit(1))
    if used_by_crop or used_by_disease:
        raise HTTPException(status_code=409, detail="This source is attached to reference records. Remove or update those records first.")
    db.delete(source)
    db.commit()
    return {"deleted": True}


@router.get("/crops")
def admin_crops(db: Session = Depends(get_db)):
    return [_crop_record(db, row) for row in db.scalars(select(CropInformation).order_by(CropInformation.name)).all()]


@router.post("/crops")
def save_crop(body: AdminCropInput, db: Session = Depends(get_db)):
    if not db.get(Source, body.source_id):
        raise HTTPException(status_code=422, detail="Select an existing source before saving crop information.")
    crop = db.scalar(select(CropInformation).where(func.lower(CropInformation.name) == body.name.strip().lower()))
    created = crop is None
    if created:
        crop = CropInformation()
        db.add(crop)
    for key, value in body.model_dump().items():
        setattr(crop, key, value.strip() if isinstance(value, str) else value)
    db.commit()
    db.refresh(crop)
    return {"created": created, "crop": _crop_record(db, crop)}


@router.delete("/crops/{crop_id}")
def delete_crop(crop_id: int, db: Session = Depends(get_db)):
    crop = db.get(CropInformation, crop_id)
    if not crop:
        raise HTTPException(status_code=404, detail="Crop record not found.")
    db.delete(crop)
    db.commit()
    return {"deleted": True}
