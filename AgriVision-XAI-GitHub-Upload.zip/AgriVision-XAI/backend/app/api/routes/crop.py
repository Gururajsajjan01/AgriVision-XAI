from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.config import get_settings
from app.models.database import PredictionRecord, Source, get_db
from app.models.schemas import SoilInput
from app.services.crop_service import get_crop, list_crops
from app.services.explainability_service import crop_explanation
from app.ml.crop_recommendation.predict import load_model, predict_candidates

router = APIRouter(tags=["crops"])

@router.get("/crops")
def crops(search: str | None = None, category: str | None = None, db: Session = Depends(get_db)):
    keys = ("name", "category", "scientific_name", "suitable_soil", "ph_min", "ph_max", "temperature_min_c", "temperature_max_c", "rainfall_min_mm", "rainfall_max_mm", "water_requirements", "growing_season", "growth_duration_days", "nutrient_requirements", "common_diseases", "cultivation", "uses")
    records = []
    for c in list_crops(db, search, category):
        row = {key: getattr(c, key) for key in keys}
        source = db.get(Source, c.source_id) if c.source_id else None
        row["source"] = {"name": source.name, "url": source.url, "citation": source.citation, "license": source.license} if source else None
        records.append(row)
    return records

@router.get("/crops/{crop_name}")
def crop_detail(crop_name: str, db: Session = Depends(get_db)):
    item = get_crop(db, crop_name)
    if not item:
        raise HTTPException(status_code=404, detail="Crop not found. Add verified, source-backed crop information first.")
    data = {key: getattr(item, key) for key in ("name", "category", "scientific_name", "suitable_soil", "ph_min", "ph_max", "temperature_min_c", "temperature_max_c", "rainfall_min_mm", "rainfall_max_mm", "water_requirements", "growing_season", "growth_duration_days", "nutrient_requirements", "common_diseases", "cultivation", "uses", "source_id")}
    source = db.get(Source, item.source_id) if item.source_id else None
    data["source"] = {"name": source.name, "url": source.url, "citation": source.citation, "license": source.license} if source else None
    return data

@router.post("/crop/recommend")
def recommend(body: SoilInput, db: Session = Depends(get_db)):
    values = body.model_dump()
    bundle = load_model(get_settings().model_dir)
    if not bundle:
        raise HTTPException(status_code=503, detail="Crop model is not trained. Follow data/README.md and run the crop training command.")
    candidates = predict_candidates(bundle, values, 3)
    db.add(PredictionRecord(task="crop_recommendation", predicted_label=candidates[0]["crop"], model_score=candidates[0]["model_score"], created_at=datetime.now(timezone.utc).isoformat()))
    db.commit()
    return {"recommendations": candidates, "explanation": crop_explanation(bundle, values), "disclaimer": "Recommendation is based on supplied data and the trained model. Verify planting decisions with local agricultural experts. Model scores are not calibrated probabilities."}
