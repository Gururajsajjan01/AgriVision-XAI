from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.models.database import get_db
from app.services.model_status_service import get_model_status

router = APIRouter(tags=["models"])

@router.get("/models/status")
def models_status(db: Session = Depends(get_db)):
    models = get_model_status(db)
    if not models:
        return {"status": "not_evaluated", "message": "No evaluated model records yet.", "models": []}
    return {"status": "evaluated", "models": models}
