from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.models.database import get_db
from app.models.schemas import FeedbackInput
from app.services.feedback_service import save_feedback

router = APIRouter(tags=["feedback"])

@router.post("/feedback", status_code=201)
def feedback(body: FeedbackInput, db: Session = Depends(get_db)):
    row = save_feedback(db, body.module, body.useful, body.comment)
    return {"id": row.id, "received": True}
