from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.database import DiseaseInformation, Source, get_db

router = APIRouter(tags=["agricultural knowledge"])

def _format_source(db: Session, source_id: int | None):
    source = db.get(Source, source_id) if source_id else None
    return {"name": source.name, "url": source.url, "citation": source.citation, "license": source.license} if source else None

@router.get("/sources")
def sources(db: Session = Depends(get_db)):
    rows = db.scalars(select(Source).order_by(Source.name)).all()
    return [{"id": row.id, "name": row.name, "url": row.url, "citation": row.citation, "license": row.license} for row in rows]

@router.get("/diseases")
def diseases(db: Session = Depends(get_db)):
    entries = db.scalars(select(DiseaseInformation).order_by(DiseaseInformation.crop, DiseaseInformation.label)).all()
    return [{"label": e.label, "common_name": e.common_name, "crop": e.crop, "summary": e.summary, "management": e.management, "prevention": e.prevention, "source": _format_source(db, e.source_id)} for e in entries]

@router.get("/diseases/{label}")
def disease_detail(label: str, db: Session = Depends(get_db)):
    item = db.scalar(select(DiseaseInformation).where(DiseaseInformation.label.ilike(label)))
    if not item:
        raise HTTPException(status_code=404, detail="No source-backed disease entry found")
    return {"label": item.label, "common_name": item.common_name, "crop": item.crop, "summary": item.summary, "management": item.management, "prevention": item.prevention, "source": _format_source(db, item.source_id)}
