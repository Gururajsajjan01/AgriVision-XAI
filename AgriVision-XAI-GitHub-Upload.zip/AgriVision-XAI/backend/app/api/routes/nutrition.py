from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.models.database import get_db
from app.services.nutrition_service import lookup_food

router = APIRouter(tags=["nutrition"])

@router.get("/nutrition/{food_name}")
async def nutrition(food_name: str, db: Session = Depends(get_db)):
    data = await lookup_food(db, food_name)
    data["disclaimer"] = "Nutrition information is general educational information and not medical advice. Values vary by food variety and preparation."
    return data
