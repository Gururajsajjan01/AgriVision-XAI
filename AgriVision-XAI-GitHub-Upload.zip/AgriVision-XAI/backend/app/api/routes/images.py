import base64
from datetime import datetime, timezone
from io import BytesIO
import numpy as np
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from PIL import Image
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.config import get_settings
from app.models.database import DiseaseInformation, PredictionRecord, Source, get_db
from app.ml.disease_detection.preprocess import validate_image_bytes
from app.ml.disease_detection.predict import load_predictor, predict_image
from app.ml.disease_detection.gradcam import make_gradcam

router = APIRouter(tags=["image models"])

async def _read_image(file: UploadFile):
    settings = get_settings()
    if file.content_type not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(status_code=415, detail="Upload a JPG, PNG, or WEBP image")
    data = await file.read(settings.max_image_mb * 1024 * 1024 + 1)
    try:
        validate_image_bytes(data, settings.max_image_mb * 1024 * 1024)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return data

@router.post("/disease/predict")
async def disease_predict(file: UploadFile = File(...), db: Session = Depends(get_db)):
    data = await _read_image(file)
    predictor = load_predictor(get_settings().model_dir, "disease_detection")
    if predictor is None:
        raise HTTPException(status_code=503, detail="Disease model is not trained. Obtain a licensed image dataset and train it first.")
    result = predict_image(predictor, data)
    condition = db.scalar(select(DiseaseInformation).where(DiseaseInformation.label.ilike(result["predicted_class"])))
    source = db.get(Source, condition.source_id) if condition and condition.source_id else None
    result.update({"status": "healthy" if "healthy" in result["predicted_class"].lower() else "disease_or_condition", "condition_information": condition.summary if condition else "Condition details are not curated yet; verify the prediction with an agricultural professional.", "management_information": condition.management if condition else "Use integrated pest management guidance from a local agricultural extension service. Avoid treatment decisions based only on this prediction.", "prevention_information": condition.prevention if condition else None, "source": {"name": source.name, "url": source.url, "citation": source.citation} if source else None, "gradcam": None, "disclaimer": "AI prediction is informational and may be incorrect. Consult an agricultural professional for diagnosis and treatment decisions."})
    db.add(PredictionRecord(task="disease_detection", predicted_label=result["predicted_class"], model_score=result["model_score"], created_at=datetime.now(timezone.utc).isoformat())); db.commit()
    try:
        import tensorflow as tf
        image = Image.open(__import__("io").BytesIO(data)).convert("RGB").resize((224, 224))
        heat = make_gradcam(predictor[0], np.asarray(image, dtype=np.float32)[None, ...])
        gray = Image.fromarray(np.uint8(np.clip(heat, 0, 1) * 255)).resize((224, 224))
        buff = BytesIO(); gray.save(buff, format="PNG")
        result["gradcam"] = "data:image/png;base64," + base64.b64encode(buff.getvalue()).decode("ascii")
    except (ValueError, ImportError, RuntimeError):
        pass
    return result

@router.post("/crop-classification/predict")
async def classification_predict(file: UploadFile = File(...), db: Session = Depends(get_db)):
    data = await _read_image(file)
    predictor = load_predictor(get_settings().model_dir, "crop_classification")
    if predictor is None:
        raise HTTPException(status_code=503, detail="Crop image classifier is not trained. Train on a documented dataset first.")
    result = predict_image(predictor, data)
    db.add(PredictionRecord(task="crop_classification", predicted_label=result["predicted_class"], model_score=result["model_score"], created_at=datetime.now(timezone.utc).isoformat())); db.commit()
    return result

