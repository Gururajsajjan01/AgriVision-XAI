import csv
from pathlib import Path
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.database import CropInformation, Source

REQUIRED = {"name", "category", "source_name", "source_url", "citation", "license"}
OPTIONAL = {"scientific_name", "suitable_soil", "ph_min", "ph_max", "temperature_min_c", "temperature_max_c", "rainfall_min_mm", "rainfall_max_mm", "water_requirements", "growing_season", "growth_duration_days", "nutrient_requirements", "common_diseases", "cultivation", "uses"}

def import_catalog(db: Session, path: str | Path):
    imported = 0
    with Path(path).open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        missing = REQUIRED - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"Crop CSV is missing required provenance columns: {sorted(missing)}")
        for row in reader:
            if not all(row.get(key, "").strip() for key in REQUIRED):
                raise ValueError(f"Each crop row needs name, category, source_name, source_url, citation, license; row={reader.line_num}")
            source = db.scalar(select(Source).where(Source.url == row["source_url"].strip()))
            if not source:
                source = Source(name=row["source_name"].strip(), url=row["source_url"].strip(), citation=row["citation"].strip(), license=row["license"].strip())
                db.add(source); db.flush()
            values = {key: row.get(key) for key in OPTIONAL if row.get(key, "").strip()}
            for key in ("ph_min", "ph_max", "temperature_min_c", "temperature_max_c", "rainfall_min_mm", "rainfall_max_mm"):
                if key in values: values[key] = float(values[key])
            if "growth_duration_days" in values: values["growth_duration_days"] = int(values["growth_duration_days"])
            crop = db.scalar(select(CropInformation).where(CropInformation.name.ilike(row["name"].strip())))
            if crop:
                for key, value in values.items(): setattr(crop, key, value)
                crop.category = row["category"].strip(); crop.source_id = source.id
            else:
                db.add(CropInformation(name=row["name"].strip(), category=row["category"].strip(), source_id=source.id, **values))
            imported += 1
    db.commit()
    return imported
