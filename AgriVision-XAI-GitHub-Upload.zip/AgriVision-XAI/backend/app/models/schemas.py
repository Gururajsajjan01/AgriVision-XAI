from typing import Any
from pydantic import BaseModel, Field, HttpUrl, field_validator, model_validator


class HealthResponse(BaseModel):
    status: str
    app: str
    environment: str
    database: str


class SoilInput(BaseModel):
    nitrogen: float = Field(ge=0, le=300)
    phosphorus: float = Field(ge=0, le=300)
    potassium: float = Field(ge=0, le=400)
    temperature: float = Field(ge=-10, le=60)
    humidity: float = Field(ge=0, le=100)
    ph: float = Field(ge=0, le=14)
    rainfall: float = Field(ge=0, le=5000)


class FeedbackInput(BaseModel):
    module: str = Field(min_length=1, max_length=80)
    useful: bool
    comment: str = Field(default="", max_length=2000)


class CropCreate(BaseModel):
    name: str
    category: str = "Other"
    scientific_name: str = ""
    suitable_soil: str = ""
    ph_min: float | None = None
    ph_max: float | None = None
    temperature_min_c: float | None = None
    temperature_max_c: float | None = None
    rainfall_min_mm: float | None = None
    rainfall_max_mm: float | None = None
    water_requirements: str = ""
    growing_season: str = ""
    growth_duration_days: int | None = None
    nutrient_requirements: str = ""
    common_diseases: str = ""
    cultivation: str = ""
    uses: str = ""
    source_id: int | None = None


class WeatherInput(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)


class WeatherResponse(BaseModel):
    latitude: float
    longitude: float
    timezone: str
    current: dict[str, Any]
    daily: dict[str, Any]
    source: str


class AdminSourceInput(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    url: HttpUrl
    citation: str = Field(min_length=1, max_length=2000)
    license: str = Field(min_length=1, max_length=200)

    @field_validator("name", "citation", "license")
    @classmethod
    def trim_required_source_fields(cls, value: str):
        value = value.strip()
        if not value:
            raise ValueError("this field cannot be blank")
        return value


class AdminCropInput(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    category: str = Field(min_length=1, max_length=80)
    source_id: int = Field(ge=1)
    scientific_name: str = Field(default="", max_length=180)
    suitable_soil: str = Field(default="", max_length=4000)
    ph_min: float | None = Field(default=None, ge=0, le=14)
    ph_max: float | None = Field(default=None, ge=0, le=14)
    temperature_min_c: float | None = Field(default=None, ge=-50, le=70)
    temperature_max_c: float | None = Field(default=None, ge=-50, le=70)
    rainfall_min_mm: float | None = Field(default=None, ge=0, le=20000)
    rainfall_max_mm: float | None = Field(default=None, ge=0, le=20000)
    water_requirements: str = Field(default="", max_length=4000)
    growing_season: str = Field(default="", max_length=200)
    growth_duration_days: int | None = Field(default=None, ge=1, le=3650)
    nutrient_requirements: str = Field(default="", max_length=4000)
    common_diseases: str = Field(default="", max_length=4000)
    cultivation: str = Field(default="", max_length=8000)
    uses: str = Field(default="", max_length=4000)

    @field_validator("name", "category")
    @classmethod
    def trim_required_crop_fields(cls, value: str):
        value = value.strip()
        if not value:
            raise ValueError("this field cannot be blank")
        return value

    @model_validator(mode="after")
    def ranges_are_ordered(self):
        for low, high in ((self.ph_min, self.ph_max), (self.temperature_min_c, self.temperature_max_c), (self.rainfall_min_mm, self.rainfall_max_mm)):
            if low is not None and high is not None and low > high:
                raise ValueError("minimum values must not exceed maximum values")
        return self

