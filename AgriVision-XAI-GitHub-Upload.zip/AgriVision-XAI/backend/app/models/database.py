from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, create_engine
from sqlalchemy.orm import DeclarativeBase, mapped_column, sessionmaker

from app.core.config import get_settings


class Base(DeclarativeBase):
    pass


class Source(Base):
    __tablename__ = "sources"
    id = mapped_column(Integer, primary_key=True)
    name = mapped_column(String(200), nullable=False)
    url = mapped_column(String(1000), nullable=False)
    citation = mapped_column(Text, default="")
    license = mapped_column(String(200), default="Unspecified")


class CropInformation(Base):
    __tablename__ = "crop_information"
    id = mapped_column(Integer, primary_key=True)
    name = mapped_column(String(120), unique=True, index=True, nullable=False)
    category = mapped_column(String(80), default="Other")
    scientific_name = mapped_column(String(180), default="")
    suitable_soil = mapped_column(Text, default="")
    ph_min = mapped_column(Float, nullable=True)
    ph_max = mapped_column(Float, nullable=True)
    temperature_min_c = mapped_column(Float, nullable=True)
    temperature_max_c = mapped_column(Float, nullable=True)
    rainfall_min_mm = mapped_column(Float, nullable=True)
    rainfall_max_mm = mapped_column(Float, nullable=True)
    water_requirements = mapped_column(Text, default="")
    growing_season = mapped_column(String(200), default="")
    growth_duration_days = mapped_column(Integer, nullable=True)
    nutrient_requirements = mapped_column(Text, default="")
    common_diseases = mapped_column(Text, default="")
    cultivation = mapped_column(Text, default="")
    uses = mapped_column(Text, default="")
    source_id = mapped_column(ForeignKey("sources.id"), nullable=True)


class NutritionEntry(Base):
    __tablename__ = "nutrition"
    id = mapped_column(Integer, primary_key=True)
    food_name = mapped_column(String(160), index=True, nullable=False)
    fdc_id = mapped_column(Integer, nullable=True, unique=True)
    basis = mapped_column(String(100), default="per 100 g")
    calories_kcal = mapped_column(Float, nullable=True)
    protein_g = mapped_column(Float, nullable=True)
    carbohydrates_g = mapped_column(Float, nullable=True)
    fat_g = mapped_column(Float, nullable=True)
    fiber_g = mapped_column(Float, nullable=True)
    calcium_mg = mapped_column(Float, nullable=True)
    iron_mg = mapped_column(Float, nullable=True)
    potassium_mg = mapped_column(Float, nullable=True)
    magnesium_mg = mapped_column(Float, nullable=True)
    zinc_mg = mapped_column(Float, nullable=True)
    vitamin_c_mg = mapped_column(Float, nullable=True)
    vitamin_a_mcg = mapped_column(Float, nullable=True)
    vitamin_b6_mg = mapped_column(Float, nullable=True)
    vitamin_e_mg = mapped_column(Float, nullable=True)
    source_name = mapped_column(String(200), default="")
    source_url = mapped_column(String(1000), default="")


class DiseaseInformation(Base):
    __tablename__ = "diseases"
    id = mapped_column(Integer, primary_key=True)
    label = mapped_column(String(180), unique=True, index=True, nullable=False)
    common_name = mapped_column(String(180), default="")
    crop = mapped_column(String(120), default="")
    summary = mapped_column(Text, default="")
    management = mapped_column(Text, default="")
    prevention = mapped_column(Text, default="")
    source_id = mapped_column(ForeignKey("sources.id"), nullable=True)


class PredictionRecord(Base):
    __tablename__ = "model_predictions"
    id = mapped_column(Integer, primary_key=True)
    task = mapped_column(String(100), nullable=False)
    predicted_label = mapped_column(String(180), nullable=False)
    model_score = mapped_column(Float, nullable=True)
    created_at = mapped_column(String(40), nullable=False)


class Feedback(Base):
    __tablename__ = "feedback"
    id = mapped_column(Integer, primary_key=True)
    module = mapped_column(String(80), nullable=False)
    useful = mapped_column(Boolean, nullable=False)
    comment = mapped_column(Text, default="")
    created_at = mapped_column(String(40), nullable=False)


class ModelRun(Base):
    __tablename__ = "model_runs"
    id = mapped_column(Integer, primary_key=True)
    model_name = mapped_column(String(120), unique=True, nullable=False)
    task = mapped_column(String(100), nullable=False)
    dataset_name = mapped_column(String(200), default="")
    dataset_samples = mapped_column(Integer, nullable=True)
    class_count = mapped_column(Integer, nullable=True)
    train_samples = mapped_column(Integer, nullable=True)
    validation_samples = mapped_column(Integer, nullable=True)
    test_samples = mapped_column(Integer, nullable=True)
    accuracy = mapped_column(Float, nullable=True)
    precision = mapped_column(Float, nullable=True)
    recall = mapped_column(Float, nullable=True)
    f1 = mapped_column(Float, nullable=True)
    inference_ms = mapped_column(Float, nullable=True)
    evaluated_at = mapped_column(String(40), nullable=True)
    metrics_json = mapped_column(Text, default="{}")


def _make_engine():
    url = get_settings().database_url
    connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
    return create_engine(url, connect_args=connect_args, pool_pre_ping=True)


engine = _make_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


