import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes.health import router as health_router
from app.core.config import get_settings
from app.models.database import Base, engine
from app.api.routes import admin, crop, feedback, images, knowledge, models, nutrition, weather

settings = get_settings()
logging.basicConfig(level=settings.log_level.upper())
Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, version="0.1.0", description="Research foundation for explainable agriculture decision support.")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True, allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"], allow_headers=["*"])
app.include_router(health_router, prefix="/api")
for route in (admin.router, crop.router, feedback.router, images.router, knowledge.router, models.router, nutrition.router, weather.router):
    app.include_router(route, prefix="/api")

@app.get("/")
def root():
    return {"name": settings.app_name, "docs": "/docs", "health": "/api/health"}
