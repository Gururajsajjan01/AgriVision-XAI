from pathlib import Path
import json
from app.core.config import get_settings


def crop_explanation(bundle=None, input_values=None):
    path = Path(get_settings().model_dir) / "crop_recommendation.metrics.json"
    if not path.exists():
        return {"available": False, "method": None, "feature_importances": [], "note": "No crop model has been evaluated."}
    metrics = json.loads(path.read_text(encoding="utf-8"))
    importances = metrics.get("feature_importances", {})
    ranked = [{"feature": k, "importance": v} for k, v in sorted(importances.items(), key=lambda pair: pair[1], reverse=True)]
    if bundle and input_values is not None:
        try:
            import shap
            import pandas as pd
            features = bundle["features"]
            row = pd.DataFrame([[input_values[k] for k in features]], columns=features)
            explanation = shap.TreeExplainer(bundle["model"])(row)
            arr = explanation.values
            import numpy as np
            if arr.ndim == 3:
                predicted = bundle["model"].predict(row)[0]
                class_index = list(bundle["model"].classes_).index(predicted)
                arr = arr[0, :, class_index]
            else:
                arr = arr[0]
            local = [{"feature": features[i], "shap_value": float(arr[i])} for i in range(len(features))]
            local.sort(key=lambda item: abs(item["shap_value"]), reverse=True)
            return {"available": True, "method": "SHAP TreeExplainer", "feature_importances": ranked, "local_explanation": local, "note": "SHAP values explain this model output relative to the explainer baseline; they are not causal effects."}
        except (ImportError, ValueError, TypeError, IndexError):
            pass
    return {"available": True, "method": "Random Forest impurity feature importance", "feature_importances": ranked, "note": "These are model-wide relative importances, not causal effects or a per-field explanation. Install requirements-xai.txt for per-prediction SHAP values."}
