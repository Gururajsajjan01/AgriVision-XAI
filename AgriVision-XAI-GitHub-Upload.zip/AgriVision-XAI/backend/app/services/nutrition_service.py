import httpx
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.config import get_settings
from app.models.database import NutritionEntry


def get_local_food(db: Session, name: str):
    return db.scalar(select(NutritionEntry).where(NutritionEntry.food_name.ilike(name)))


async def lookup_food(db: Session, name: str):
    local = get_local_food(db, name)
    if local:
        return {"food_name": local.food_name, "basis": local.basis, "nutrients": {k: getattr(local, k) for k in ("calories_kcal", "protein_g", "carbohydrates_g", "fat_g", "fiber_g", "calcium_mg", "iron_mg", "potassium_mg", "magnesium_mg", "zinc_mg", "vitamin_c_mg", "vitamin_a_mcg", "vitamin_b6_mg", "vitamin_e_mg")}, "source": local.source_name, "source_url": local.source_url}
    settings = get_settings()
    if not settings.usda_fdc_api_key:
        raise HTTPException(status_code=404, detail="Food not found in local records. Configure USDA_FDC_API_KEY to search FoodData Central.")
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.post(f"{settings.usda_fdc_base_url}/foods/search", params={"api_key": settings.usda_fdc_api_key}, json={"query": name, "dataType": ["Foundation", "SR Legacy"], "pageSize": 1})
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail="Nutrition data provider is unavailable") from exc
    if response.is_error:
        raise HTTPException(status_code=502, detail="Nutrition data provider is unavailable")
    foods = response.json().get("foods", [])
    if not foods:
        raise HTTPException(status_code=404, detail="No matching food found in FoodData Central")
    item = foods[0]
    nutrient_map = {"Energy": "calories_kcal", "Protein": "protein_g", "Carbohydrate, by difference": "carbohydrates_g", "Total lipid (fat)": "fat_g", "Fiber, total dietary": "fiber_g", "Calcium, Ca": "calcium_mg", "Iron, Fe": "iron_mg", "Potassium, K": "potassium_mg", "Magnesium, Mg": "magnesium_mg", "Zinc, Zn": "zinc_mg", "Vitamin C, total ascorbic acid": "vitamin_c_mg", "Vitamin A, RAE": "vitamin_a_mcg", "Vitamin B-6": "vitamin_b6_mg", "Vitamin E (alpha-tocopherol)": "vitamin_e_mg"}
    nutrients = {key: None for key in nutrient_map.values()}
    raw = []
    for entry in item.get("foodNutrients", []):
        label = entry.get("nutrientName", "")
        if label in nutrient_map:
            nutrients[nutrient_map[label]] = entry.get("value")
        raw.append({"name": label, "value": entry.get("value"), "unit": entry.get("unitName")})
    fdc_id = item.get("fdcId")
    source_url = f"https://fdc.nal.usda.gov/food-details/{fdc_id}/nutrients"
    entry = NutritionEntry(food_name=item.get("description", name), fdc_id=fdc_id, basis="FDC food record; see linked source for reporting basis", source_name="USDA FoodData Central", source_url=source_url, **nutrients)
    db.add(entry)
    try:
        db.commit()
    except Exception:
        db.rollback()  # Concurrent lookup may have cached this FDC record already.
    return {"food_name": item.get("description", name), "basis": entry.basis, "nutrients": nutrients, "nutrient_details": raw, "source": "USDA FoodData Central", "source_url": source_url}

