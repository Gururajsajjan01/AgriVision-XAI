from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.database import Feedback


def save_feedback(db: Session, module: str, useful: bool, comment: str):
    row = Feedback(module=module, useful=useful, comment=comment.strip(), created_at=datetime.now(timezone.utc).isoformat())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row

