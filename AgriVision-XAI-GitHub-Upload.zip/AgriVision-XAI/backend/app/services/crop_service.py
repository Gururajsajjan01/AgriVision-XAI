from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.database import CropInformation


def list_crops(db: Session, search: str | None = None, category: str | None = None):
    query = select(CropInformation).order_by(CropInformation.name)
    if search:
        query = query.where(CropInformation.name.ilike(f"%{search}%"))
    if category and category.lower() != "all":
        query = query.where(CropInformation.category.ilike(category))
    return db.scalars(query).all()


def get_crop(db: Session, name: str):
    return db.scalar(select(CropInformation).where(CropInformation.name.ilike(name)))

