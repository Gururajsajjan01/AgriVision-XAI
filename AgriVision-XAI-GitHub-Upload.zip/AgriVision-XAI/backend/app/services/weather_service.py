import httpx
from fastapi import HTTPException
from app.core.config import get_settings


async def get_weather(latitude: float, longitude: float):
    params = {"latitude": latitude, "longitude": longitude, "current": "temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m", "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum", "forecast_days": 7, "timezone": "auto"}
    try:
        async with httpx.AsyncClient(timeout=get_settings().weather_timeout_seconds) as client:
            response = await client.get("https://api.open-meteo.com/v1/forecast", params=params)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail="Weather provider is unavailable; try again later") from exc
    data = response.json()
    return {"latitude": data["latitude"], "longitude": data["longitude"], "timezone": data.get("timezone", "UTC"), "current": data.get("current", {}), "daily": data.get("daily", {}), "source": "Open-Meteo"}

