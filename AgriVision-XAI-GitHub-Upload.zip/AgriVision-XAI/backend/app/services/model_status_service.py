import json
from pathlib import Path
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.config import get_settings
from app.models.database import ModelRun


def get_model_status(db: Session):
    rows = db.scalars(select(ModelRun).order_by(ModelRun.task, ModelRun.model_name)).all()
    records = [{"model_name": r.model_name, "task": r.task, "dataset_name": r.dataset_name, "dataset_samples": r.dataset_samples, "class_count": r.class_count, "train_samples": r.train_samples, "validation_samples": r.validation_samples, "test_samples": r.test_samples, "accuracy": r.accuracy, "precision": r.precision, "recall": r.recall, "f1": r.f1, "inference_ms": r.inference_ms, "evaluated_at": r.evaluated_at, "metrics": json.loads(r.metrics_json or "{}") } for r in rows]
    seen = {r["task"] for r in records}
    model_dir = Path(get_settings().model_dir)
    for task in ("crop_recommendation", "disease_detection", "crop_classification"):
        path = model_dir / f"{task}.metrics.json"
        if task not in seen and path.exists():
            metrics = json.loads(path.read_text(encoding="utf-8"))
            records.append({**metrics, "metrics": metrics})
    return records

