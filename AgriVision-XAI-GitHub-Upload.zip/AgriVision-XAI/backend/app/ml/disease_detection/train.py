import json
import time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from .dataset import discover_image_folders
from .model import build_model


def train_image_model(dataset_dir, model_dir, task="disease_detection", architecture="MobileNetV2", epochs=8, seed=42):
    import tensorflow as tf
    folders = discover_image_folders(dataset_dir)
    names = sorted(folders)
    paths, labels = [], []
    for i, name in enumerate(names):
        paths.extend(map(str, folders[name])); labels.extend([i] * len(folders[name]))
    if min(np.bincount(labels)) < 4:
        raise ValueError("Each class needs at least four images to create train/validation/test splits")
    hold_size = max(len(names) * 2, round(len(paths) * .30))
    x_train, x_hold, y_train, y_hold = train_test_split(paths, labels, test_size=hold_size, random_state=seed, stratify=labels)
    test_size = max(len(names), round(len(x_hold) * .50))
    x_val, x_test, y_val, y_test = train_test_split(x_hold, y_hold, test_size=test_size, random_state=seed, stratify=y_hold)

    def make_dataset(xs, ys, training=False):
        ds = tf.data.Dataset.from_tensor_slices((xs, ys))
        def load(path, label):
            image = tf.io.decode_image(tf.io.read_file(path), channels=3, expand_animations=False)
            image = tf.image.resize(image, [224, 224])
            return tf.cast(image, tf.float32), label
        ds = ds.map(load, num_parallel_calls=tf.data.AUTOTUNE)
        if training:
            ds = ds.shuffle(len(xs), seed=seed).map(lambda image, label: (tf.image.random_flip_left_right(image), label), num_parallel_calls=tf.data.AUTOTUNE)
        return ds.batch(32).prefetch(tf.data.AUTOTUNE)

    train_ds, val_ds, test_ds = make_dataset(x_train, y_train, True), make_dataset(x_val, y_val), make_dataset(x_test, y_test)
    model = build_model(len(names), architecture)
    history = model.fit(train_ds, validation_data=val_ds, epochs=epochs, verbose=2)
    started = time.perf_counter()
    probs = model.predict(test_ds, verbose=0)
    inference_ms = (time.perf_counter() - started) * 1000 / len(x_test)
    pred = probs.argmax(axis=1)
    precision, recall, f1, _ = precision_recall_fscore_support(y_test, pred, average="weighted", zero_division=0)
    metrics = {"model_name": f"{architecture} {task}", "task": task, "dataset_name": Path(dataset_dir).name, "dataset_samples": len(paths), "class_count": len(names), "train_samples": len(x_train), "validation_samples": len(x_val), "test_samples": len(x_test), "accuracy": float(accuracy_score(y_test, pred)), "precision": float(precision), "recall": float(recall), "f1": float(f1), "inference_ms": float(inference_ms), "classification_report": classification_report(y_test, pred, target_names=names, output_dict=True, zero_division=0), "confusion_matrix": confusion_matrix(y_test, pred).tolist(), "labels": names, "evaluated_at": datetime.now(timezone.utc).isoformat(), "split_seed": seed, "split_method": "stratified random image-level 70/15/15 split", "limitations": "Image-level splits may leak near-duplicate or same-plant images; validate with group/site-held-out data before field use.", "training_history": {k: [float(v) for v in vals] for k, vals in history.history.items()}}
    out = Path(model_dir); out.mkdir(parents=True, exist_ok=True)
    model.save(out / f"{task}.keras")
    (out / f"{task}.classes.json").write_text(json.dumps(names, indent=2), encoding="utf-8")
    (out / f"{task}.metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics
