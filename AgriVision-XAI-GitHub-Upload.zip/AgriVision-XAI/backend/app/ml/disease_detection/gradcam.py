import numpy as np


def make_gradcam(model, image_array, class_index=None):
    import tensorflow as tf
    conv = next((layer for layer in reversed(model.layers) if isinstance(layer, tf.keras.layers.Conv2D)), None)
    if conv is None:
        raise ValueError("Grad-CAM requires a model with a convolutional feature layer")
    grad_model = tf.keras.Model(model.inputs, [conv.output, model.output])
    with tf.GradientTape() as tape:
        feature_maps, logits = grad_model(image_array)
        index = int(tf.argmax(logits[0])) if class_index is None else int(class_index)
        loss = logits[:, index]
    gradients = tape.gradient(loss, feature_maps)
    weights = tf.reduce_mean(gradients, axis=(1, 2))
    heatmap = tf.reduce_sum(feature_maps[0] * weights[0][None, None, :], axis=-1)
    heatmap = tf.maximum(heatmap, 0)
    heatmap /= tf.reduce_max(heatmap) + 1e-8
    return np.asarray(heatmap)
