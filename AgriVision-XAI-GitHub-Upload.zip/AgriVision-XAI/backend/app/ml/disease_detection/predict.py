import json
from pathlib import Path
import numpy as np
from PIL import Image


def load_predictor(model_dir, task="disease_detection"):
    root = Path(model_dir)
    model_path, classes_path = root / f"{task}.keras", root / f"{task}.classes.json"
    if not model_path.exists() or not classes_path.exists():
        return None
    import tensorflow as tf
    return tf.keras.models.load_model(model_path), json.loads(classes_path.read_text(encoding="utf-8"))


def predict_image(predictor, image_bytes):
    model, classes = predictor
    image = Image.open(__import__("io").BytesIO(image_bytes)).convert("RGB").resize((224, 224))
    scores = model.predict(np.asarray(image, dtype=np.float32)[None, ...], verbose=0)[0]
    index = int(scores.argmax())
    return {"predicted_class": classes[index], "model_score": float(scores[index]), "classes": [{"class": classes[i], "model_score": float(scores[i])} for i in scores.argsort()[::-1][:3]]}
