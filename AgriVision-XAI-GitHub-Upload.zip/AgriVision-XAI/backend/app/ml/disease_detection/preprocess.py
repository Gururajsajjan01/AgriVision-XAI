from pathlib import Path
from PIL import Image, UnidentifiedImageError

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}


def validate_image_bytes(data: bytes, max_bytes: int):
    if not data:
        raise ValueError("Image is empty")
    if len(data) > max_bytes:
        raise ValueError(f"Image exceeds the {max_bytes // (1024 * 1024)} MB upload limit")
    try:
        image = Image.open(__import__("io").BytesIO(data))
        if image.width > 6000 or image.height > 6000 or image.width * image.height > 25_000_000:
            raise ValueError("Image dimensions exceed the supported limit")
        image.verify()
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ValueError("File is not a valid supported image") from exc
    return True


def validate_image_path(path: str | Path):
    path = Path(path)
    if path.suffix.lower() not in ALLOWED_EXTENSIONS:
        raise ValueError("Image must be JPG, PNG, or WEBP")
    with Image.open(path) as img:
        img.verify()
