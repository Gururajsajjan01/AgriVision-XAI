from pathlib import Path


def discover_image_folders(root: str | Path, supported_extensions=(".jpg", ".jpeg", ".png", ".webp")):
    root = Path(root)
    if not root.is_dir():
        raise FileNotFoundError(f"Image dataset directory does not exist: {root}")
    folders = {folder.name: [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in supported_extensions] for folder in root.iterdir() if folder.is_dir()}
    folders = {name: paths for name, paths in folders.items() if paths}
    if len(folders) < 2:
        raise ValueError("Dataset must contain at least two class folders with supported image files")
    return folders
