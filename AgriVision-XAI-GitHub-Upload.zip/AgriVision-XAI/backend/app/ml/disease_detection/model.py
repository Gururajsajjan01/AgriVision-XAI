def build_model(num_classes: int, architecture: str = "MobileNetV2", image_size: int = 224):
    import tensorflow as tf
    backbones = {"MobileNetV2": tf.keras.applications.MobileNetV2, "EfficientNetB0": tf.keras.applications.EfficientNetB0, "ResNet50": tf.keras.applications.ResNet50}
    if architecture not in backbones:
        raise ValueError(f"Unsupported architecture {architecture}; choose {', '.join(backbones)}")
    inputs = tf.keras.Input(shape=(image_size, image_size, 3))
    if architecture == "MobileNetV2":
        feature_map = tf.keras.applications.mobilenet_v2.preprocess_input(inputs)
    elif architecture == "ResNet50":
        feature_map = tf.keras.applications.resnet.preprocess_input(inputs)
    else:
        feature_map = inputs
    base = backbones[architecture](include_top=False, weights="imagenet", input_tensor=feature_map)
    base.trainable = False
    x = tf.keras.layers.GlobalAveragePooling2D()(base.output)
    x = tf.keras.layers.Dropout(0.25)(x)
    outputs = tf.keras.layers.Dense(num_classes, activation="softmax")(x)
    model = tf.keras.Model(inputs, outputs)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return model
