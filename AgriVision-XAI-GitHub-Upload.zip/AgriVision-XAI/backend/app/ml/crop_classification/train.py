from app.ml.disease_detection.train import train_image_model

def train_crop_classifier(dataset_dir, model_dir, architecture="MobileNetV2", epochs=8, seed=42):
    return train_image_model(dataset_dir, model_dir, task="crop_classification", architecture=architecture, epochs=epochs, seed=seed)
