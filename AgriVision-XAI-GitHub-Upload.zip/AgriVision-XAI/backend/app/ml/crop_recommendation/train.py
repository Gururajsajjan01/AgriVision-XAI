import json
import time
from datetime import datetime, timezone
from pathlib import Path
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from .config import FEATURES, MODEL_FILENAME
from .preprocess import load_crop_csv


def train_model(dataset: str | Path, model_dir: str | Path, seed: int = 42):
    data = load_crop_csv(dataset)
    x, y = data[FEATURES], data["target"]
    counts = y.value_counts()
    if counts.min() < 2:
        raise ValueError("Each crop class needs at least two examples for a stratified holdout")
    test_size = max(y.nunique(), round(len(y) * .2))
    if test_size >= len(y):
        raise ValueError("Dataset is too small for train/test evaluation")
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=test_size, random_state=seed, stratify=y)
    model = RandomForestClassifier(n_estimators=300, class_weight="balanced_subsample", random_state=seed, n_jobs=-1)
    model.fit(x_train, y_train)
    started = time.perf_counter()
    predicted = model.predict(x_test)
    inference_ms = (time.perf_counter() - started) * 1000 / len(x_test)
    precision, recall, f1, _ = precision_recall_fscore_support(y_test, predicted, average="weighted", zero_division=0)
    report = classification_report(y_test, predicted, output_dict=True, zero_division=0)
    labels = list(model.classes_)
    metrics = {"model_name": "Random Forest crop recommendation", "task": "crop_recommendation", "dataset_name": Path(dataset).name, "dataset_samples": int(len(data)), "input_rows": int(data.attrs.get("input_rows", len(data))), "dropped_rows": int(data.attrs.get("dropped_rows", 0)), "class_count": int(y.nunique()), "train_samples": int(len(x_train)), "validation_samples": 0, "test_samples": int(len(x_test)), "accuracy": float(accuracy_score(y_test, predicted)), "precision": float(precision), "recall": float(recall), "f1": float(f1), "inference_ms": float(inference_ms), "classification_report": report, "confusion_matrix": confusion_matrix(y_test, predicted, labels=labels).tolist(), "labels": labels, "feature_importances": dict(zip(FEATURES, map(float, model.feature_importances_))), "evaluated_at": datetime.now(timezone.utc).isoformat(), "split_seed": seed, "split_method": "stratified 80/20 holdout"}
    out = Path(model_dir); out.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "features": FEATURES, "metrics": metrics}, out / MODEL_FILENAME)
    (out / "crop_recommendation.metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics
