from pathlib import Path
import pandas as pd
from .config import FEATURES, TARGET_CANDIDATES

FEATURE_ALIASES = {"nitrogen": ("nitrogen", "n"), "phosphorus": ("phosphorus", "phosphorous", "p"), "potassium": ("potassium", "k"), "temperature": ("temperature", "temp"), "humidity": ("humidity", "relative_humidity"), "ph": ("ph", "soil_ph"), "rainfall": ("rainfall", "rain")}


def load_crop_csv(path: str | Path):
    frame = pd.read_csv(path)
    normalized = {str(c).strip().lower(): c for c in frame.columns}
    columns = {feature: next((normalized[a] for a in FEATURE_ALIASES[feature] if a in normalized), None) for feature in FEATURES}
    missing = [name for name, column in columns.items() if column is None]
    target = next((normalized[name] for name in TARGET_CANDIDATES if name in normalized), None)
    if missing or target is None:
        raise ValueError(f"CSV requires features {FEATURES} and one target column from {TARGET_CANDIDATES}; missing={missing}")
    clean = frame[[columns[name] for name in FEATURES] + [target]].copy()
    clean.columns = FEATURES + ["target"]
    for col in FEATURES:
        clean[col] = pd.to_numeric(clean[col], errors="coerce")
    clean["target"] = clean["target"].astype("string").str.strip()
    input_rows = len(clean)
    clean = clean.dropna()
    clean = clean[clean.target != ""]
    if clean.empty or clean.target.nunique() < 2:
        raise ValueError("Dataset needs non-empty feature rows and at least two target classes")
    clean.attrs["input_rows"] = input_rows
    clean.attrs["dropped_rows"] = input_rows - len(clean)
    return clean
