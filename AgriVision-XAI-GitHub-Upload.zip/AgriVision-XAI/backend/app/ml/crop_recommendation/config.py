FEATURES = ["nitrogen", "phosphorus", "potassium", "temperature", "humidity", "ph", "rainfall"]
TARGET_CANDIDATES = ("label", "crop", "crop_name", "target")
MODEL_FILENAME = "crop_recommendation.joblib"
