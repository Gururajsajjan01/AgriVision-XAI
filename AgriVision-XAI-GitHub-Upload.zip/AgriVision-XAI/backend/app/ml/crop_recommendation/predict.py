from pathlib import Path
import joblib
import pandas as pd
from .config import FEATURES, MODEL_FILENAME


def load_model(model_dir: str | Path):
    path = Path(model_dir) / MODEL_FILENAME
    if not path.exists():
        return None
    return joblib.load(path)


def predict_candidates(bundle, values: dict, limit: int = 3):
    if not bundle:
        return None
    model = bundle["model"]
    frame = pd.DataFrame([[values[k] for k in FEATURES]], columns=FEATURES)
    scores = model.predict_proba(frame)[0]
    order = scores.argsort()[::-1][:limit]
    return [{"crop": str(model.classes_[i]), "model_score": float(scores[i])} for i in order]
