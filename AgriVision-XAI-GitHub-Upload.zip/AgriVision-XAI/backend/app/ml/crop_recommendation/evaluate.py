import argparse
import json
from .train import train_model

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train/evaluate crop Random Forest from a labeled CSV holdout.")
    parser.add_argument("dataset")
    parser.add_argument("--model-dir", default="../../models")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    print(json.dumps(train_model(args.dataset, args.model_dir, args.seed), indent=2))
