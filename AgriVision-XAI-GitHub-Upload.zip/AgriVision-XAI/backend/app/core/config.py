from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "AgriVision-XAI"
    app_env: str = "development"
    database_url: str = "sqlite:///./agrivision.db"
    frontend_origins: str = "http://localhost:5173,http://127.0.0.1:5173"
    log_level: str = "INFO"
    model_dir: str = str(Path(__file__).resolve().parents[3] / "models")
    max_image_mb: int = 10
    usda_fdc_api_key: str = ""
    usda_fdc_base_url: str = "https://api.nal.usda.gov/fdc/v1"
    weather_timeout_seconds: float = 8.0
    admin_api_key: str = ""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.frontend_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()

