# Dataset documentation

No raw datasets are included and no dataset counts are measured in this checkout. Record each actual acquisition using this template:

| Field | Record |
|---|---|
| Dataset name/version | |
| Publisher/source URL/access date | |
| License and permitted use | |
| Citation/DOI | |
| Task/features/classes | |
| Publisher-stated samples/classes | |
| Locally obtained samples/classes | |
| Preprocessing and excluded items | |
| Train/validation/test split method and counts | |
| Grouping/leakage controls | |
| Bias, representation gaps, known limitations | |

See `data/README.md` for supported formats and acquisition notes. Don't copy statistics from a web page into a local experiment as though those samples were downloaded or used.
