# Research methodology

## Research questions

1. How does a Random Forest classify crop labels from documented N/P/K, temperature, humidity, pH, and rainfall measurements?
2. How do transfer-learning image classifiers perform on a documented leaf-disease dataset and an independently sourced crop-product dataset?
3. What feature-level explanation can be reported with each measured model output?

## Data and preprocessing

No data is preloaded. Each dataset must have documented source, terms/license, citation, release, published and locally measured sample counts, class distribution, units, acquisition date, and limitations. Crop CSVs are parsed into numeric features; invalid/missing rows are dropped and counted in preparation before training. Image folders are validated, resized to 224×224 RGB, and split stratified by image into train/validation/test subsets. That image-level split is only a baseline; grouped plant, collection site, or field-held-out evaluation is necessary to assess leakage and generalization.

## Models and training

Crop baseline: Random Forest with balanced subsample weights and deterministic stratified holdout; joblib artifacts. Image baseline: frozen ImageNet transfer learning backbones MobileNetV2, EfficientNetB0, or ResNet50 with global average pooling, dropout, softmax output, and light image flipping augmentation. Model/dataset parameters and seeds are written with metrics.

## Evaluation

Report test accuracy, weighted precision/recall/F1, per-class classification report, confusion matrix, data split counts, class count, and measured inference time. Image training and validation loss/accuracy histories are kept in the run manifest. Do not compare scores across incompatible datasets/splits as if they were a single benchmark. There are no measured results until an actual training run is completed.

## Explainability

Crop predictions can include SHAP TreeExplainer values when the optional SHAP package is installed; global Random Forest feature importance is the fallback. Neither describes causal effects. Image predictions return Grad-CAM highlighting model activation regions; this is not a disease localization proof.

## Limitations, ethics, and safety

Benchmarks may not represent local cultivars, field conditions, geography, season, cameras, or farmer practices. A classifier output is not diagnosis. Crop recommendation is not agronomic guarantee. Nutrient facts are based on named reference records and can differ by preparation/variety. Model and uploaded image outputs are informational; consult agricultural professionals for decisions. Avoid unsupported treatment advice, collect minimal data, do not store user images, and follow provider/dataset terms.
