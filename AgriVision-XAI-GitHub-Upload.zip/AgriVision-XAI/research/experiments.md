# Experiments

No experiments have been run with real datasets in this project. Training scripts create measured metrics files in `models/*.metrics.json` when an actual dataset is supplied. Retain the dataset source/version, code revision, train/validation/test split counts, random seed, software/platform, architecture/hyperparameters, classification report, confusion matrix, inference latency, and artifact hash for each run.

`python scripts/evaluate_models.py` displays saved result files only. Test fixtures use temporary synthetic rows solely to check code behavior; those fixtures are not project data and their scores are not research results.
