# Deployment preparation

# Deployment preparation

## Frontend (Vercel/static host)

Set the frontend project root to `frontend/`, build command to `npm run build`, and output directory to `dist`. Set `VITE_API_URL` to the deployed API origin plus `/api` (for example `https://api.example.org/api`). Configure the backend `FRONTEND_ORIGINS` to exactly the frontend origin.

## Backend (Render/Railway/Fly)

Set the service root to `backend/`. Install `requirements.txt` (plus `requirements-postgres.txt` for PostgreSQL). Run database migrations before starting the service: `python -m alembic upgrade head`. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`. Set `DATABASE_URL`, `FRONTEND_ORIGINS`, `MODEL_DIR`, and optional `USDA_FDC_API_KEY` through the host's secret/environment manager. Use PostgreSQL for multi-instance production deployments; do not use an ephemeral filesystem SQLite file for production state.

Train models outside the request worker and deploy the versioned model artifacts to a persistent artifact store or bundled image. Model files are not committed here. Apply HTTPS, authentication and rate limiting for state-changing endpoints, secret rotation, backup/retention policies, and provider/dataset license review before a public farmer rollout. Test database migrations on a backup/staging database first.

