# Architecture

React/Vite provides the frontend; FastAPI owns routes, configuration, database connectivity, and future service/ML layers. SQLite is the development default. `DATABASE_URL` can target another SQLAlchemy-supported database such as PostgreSQL. The initial health endpoint checks database connectivity.
