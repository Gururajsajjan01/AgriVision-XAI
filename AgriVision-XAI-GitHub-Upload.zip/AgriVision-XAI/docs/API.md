# API reference

Local base URL: `http://localhost:8000`; interactive OpenAPI is `/docs`.

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | API and database check |
| GET | `/api/crops?search=&category=` | Source-backed crop reference search |
| GET | `/api/crops/{crop_name}` | Crop detail including citation/license |
| GET | `/api/diseases` / `/api/diseases/{label}` | Source-backed disease guidance |
| GET | `/api/sources` | Provenance records |
| POST | `/api/crop/recommend` | Soil model candidate crops and explanation; 503 until trained |
| POST | `/api/disease/predict` | Multipart image field `file`; 503 until trained |
| POST | `/api/crop-classification/predict` | Multipart image field `file`; 503 until trained |
| GET | `/api/nutrition/{food_name}` | Local cache then optional USDA FoodData Central lookup |
| GET | `/api/weather?latitude=&longitude=` | Seven-day Open-Meteo weather forecast |
| POST | `/api/feedback` | Anonymous module usefulness feedback |
| GET | `/api/models/status` | Measured model manifests or not-evaluated status |
| GET | `/api/admin/overview` | Admin counts and model readiness |
| GET/POST/DELETE | `/api/admin/sources` | Manage provenance sources |
| GET/POST/DELETE | `/api/admin/crops` | Manage source-backed crop records |

Soil JSON fields: `nitrogen`, `phosphorus`, `potassium`, `temperature`, `humidity`, `ph`, `rainfall`. Validate bounds are broad input sanity checks, not crop suitability ranges. Prediction image files must be JPEG, PNG, or WEBP, up to the configured size/dimension limits. Upload bytes are not stored.

Feedback JSON: `{"module":"weather","useful":true,"comment":"optional"}`. Do not include identifying or sensitive information in comments.

Admin requests require `X-Admin-Key`, configured through `ADMIN_API_KEY` in `backend/.env`. If no key is configured, admin routes return 503 and remain disabled. Keep the key private and use HTTPS in deployed environments.
